setup = function(){
}
c = 0
loop = function(){
    x = tp(0)
    y = tp(1)

    color(0,0,0)
    fillrect(0,0,128,128)
    
    color(255,255,255)
    text(gtx(x),10,24)
    // text(str(x),10,24)

    // x = tp(0)
    // y = tp(1)
    // color(8)
    // fillrect(x,y,5,5)
    // color(255,255,255)
    // text(str(tbtnid), x+10, y)

}